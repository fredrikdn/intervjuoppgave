// Re-export consolidated App from modules/app for single source.
export { App } from './modules/app/App';
