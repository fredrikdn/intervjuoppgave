package com.flightplanner.entity;

// TODO: implementere avatar entity (må ha laget en tabell i databasen først)
public class Avatar {
}
